package com.example.projekwisata.utils

import android.content.Context

import com.example.projekwisata.room.AppDatabase
import com.example.projekwisata.room.PostRepository
import com.example.projekwisata.room.PostSavedRepository
import com.example.projekwisata.room.Retrofit.ExRepository
import com.example.projekwisata.room.UserRepository

object DependencyInjection {
    fun provideRepository(context: Context): PostRepository {
        val database = AppDatabase.getDatabase(context)
        val appExecutors = AppExecutors()
        val dao = database.postDao()
        return PostRepository.getInstance(dao, appExecutors)
    }

    fun provideUserRepository(context: Context): UserRepository {
        val database = AppDatabase.getDatabase(context)
        val appExecutors = AppExecutors()
        val dao = database.userDao()
        return UserRepository.getInstance(dao, appExecutors)
    }

    fun provideWisataSavedRepository(context: Context): PostSavedRepository {
        val database = AppDatabase.getDatabase(context)
        val appExecutors = AppExecutors()
        val dao = database.postSavedDao()
        return PostSavedRepository.getInstance(dao, appExecutors)
    }

    fun provideExampleRepository() : ExRepository {
        return ExRepository.getInstance()
    }




}