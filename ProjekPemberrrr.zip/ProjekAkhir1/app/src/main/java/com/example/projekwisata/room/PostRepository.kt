package com.example.projekwisata.room

import androidx.lifecycle.LiveData
import com.example.projekwisata.utils.AppExecutors

class PostRepository private constructor(private val postDao: PostDao, private val appExecutors: AppExecutors) {

    fun getAllWisata(): LiveData<List<WisataEntity>> = postDao.getAllWisata()

    fun insertWisata(wisata: WisataEntity) {
        appExecutors.diskIO().execute { postDao.insertWisata(wisata) }
    }

    fun deleteWisata(wisata: WisataEntity) {
        appExecutors.diskIO().execute { postDao.deleteWisata(wisata) }
    }

    fun updateWisata(wisata: WisataEntity) {
        appExecutors.diskIO().execute { postDao.updateWisata(wisata) }
    }

    companion object {
        @Volatile
        private var instance: PostRepository? = null

        fun getInstance(
            postDao: PostDao,
            appExecutors: AppExecutors
        ): PostRepository = instance ?: synchronized(this) {
                instance ?: PostRepository(postDao, appExecutors)
            }.also { instance = it }
    }
}