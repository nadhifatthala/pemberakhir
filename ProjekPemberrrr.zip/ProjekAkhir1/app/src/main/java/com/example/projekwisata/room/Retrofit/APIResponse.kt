package com.example.projekwisata.room.Retrofit

import android.os.Parcel
import android.os.Parcelable
import com.google.gson.annotations.SerializedName

data class APIResponse(
    // Anotasi SerializedName digunakan untuk mapping antara variabel dan field JSON saat proses serialisasi dan deserialisasi
    // Variabel "name" akan dipetakan ke field JSON "name"
    @field:SerializedName("nama")
    val nama: String,

    // Variabel "avatar" akan dipetakan ke field JSON "avatar"
    @field:SerializedName("lokasi")
    val lokasi: String,

    // Variabel "description" akan dipetakan ke field JSON "description"
    @field:SerializedName("deskripsi")
    val deskripsi: String,

    @field:SerializedName("image")
    val image: String,

    // Variabel "id" akan dipetakan ke field JSON "id"
    @field:SerializedName("id")
    val id: String

) : Parcelable {
    // Konstruktor ini digunakan saat membaca data dari Parcel
    constructor(parcel: Parcel) : this(
        parcel.readString()!!, // Membaca string "name" dari Parcel
        parcel.readString()!!, // Membaca string "avatar" dari Parcel
        parcel.readString()!!, // Membaca string "description" dari Parcel
        parcel.readString()!!,
        parcel.readString()!!  // Membaca string "id" dari Parcel// Membaca string "id" dari Parcel
    )

    // Fungsi ini digunakan untuk menulis data ke Parcel
    override fun writeToParcel(dest: Parcel, flags: Int) {
        dest.writeString(nama) // Menulis string "name" ke Parcel
        dest.writeString(lokasi) // Menulis string "avatar" ke Parcel
        dest.writeString(deskripsi)
        dest.writeString(image) // Menulis string "description" ke Parcel
        dest.writeString(id) // Menulis string "id" ke Parcel
    }

    // Fungsi ini digunakan untuk mendeskripsikan jenis konten khusus yang ditangani oleh Parcelable instance
    override fun describeContents(): Int {
        return 0
    }

    // Objek CREATOR digunakan untuk membuat instance baru dari Parcelable class, baik dari Parcel yang telah ada atau array baru
    companion object CREATOR : Parcelable.Creator<APIResponse> {
        // Membuat instance baru dari Parcelable class dari Parcel yang telah ada
        override fun createFromParcel(parcel: Parcel): APIResponse {
            return APIResponse(parcel)
        }

        // Membuat array baru dari Parcelable class
        override fun newArray(size: Int): Array<APIResponse?> {
            return arrayOfNulls(size)
        }
    }
}


