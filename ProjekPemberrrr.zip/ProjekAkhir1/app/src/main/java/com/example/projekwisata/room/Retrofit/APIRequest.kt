package com.example.projekwisata.room.Retrofit

import com.google.gson.annotations.SerializedName

data class APIRequest(

    // Anotasi SerializedName digunakan untuk mapping antara variabel dan field JSON saat proses serialisasi dan deserialisasi
    // Variabel "name" akan dipetakan ke field JSON "name"
    @field:SerializedName("nama")
    val nama: String,

    // Variabel "avatar" akan dipetakan ke field JSON "avatar"
    @field:SerializedName("lokasi")
    val lokasi: String,

    @field:SerializedName("deskripsi")
    val deskripsi: String,

    // Variabel "description" akan dipetakan ke field JSON "description"
    @field:SerializedName("image")
    val image: String
)
