package com.example.projekwisata.adapter

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.example.projekwisata.R
import com.example.projekwisata.room.Retrofit.APIResponse
import com.google.android.material.imageview.ShapeableImageView
import com.google.android.material.textview.MaterialTextView

class AdapterRetrofit (private var playerList: List<APIResponse>) :
    RecyclerView.Adapter<AdapterRetrofit.PlayerViewHolder>() {

    // Kelas ViewHolder untuk menyimpan referensi view yang digunakan dalam RecyclerView
    class PlayerViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val playerName: MaterialTextView = itemView.findViewById(R.id.player_name)
        val playerDescription: MaterialTextView = itemView.findViewById(R.id.player_description)
        val lokasi: MaterialTextView = itemView.findViewById(R.id.lokasi_name)
        val playerImage: ShapeableImageView = itemView.findViewById(R.id.player_image)

    }

    // Fungsi untuk membuat ViewHolder (Melakukan setting untuk XML yang akan kita gunakan untuk menampilkan data)
    override fun onCreateViewHolder(
        parent: ViewGroup,
        viewType: Int
    ): PlayerViewHolder {
        val view: View =
            LayoutInflater.from(parent.context)
                .inflate(R.layout.activity_item_room, parent, false)
        return PlayerViewHolder(view)
    }

    // Fungsi untuk mengikat data dengan ViewHolder (memasukkan data yang kita miliki ke dalam XML ViewHolder)
    override fun onBindViewHolder(holder: PlayerViewHolder, position: Int) {
        val data = playerList[position]

        holder.playerName.text = data.nama
        holder.lokasi.text = data.lokasi
        holder.playerDescription.text = data.deskripsi.shorten(85)

        // Mengatur image
        Glide.with(holder.playerImage)
            .load(data.image)
            .into(holder.playerImage)


    }

    // Fungsi untuk mendapatkan jumlah item
    override fun getItemCount(): Int = playerList.size

    // Fungsi untuk memendekkan teks jika melebihi panjang maksimum
    private fun String.shorten(maxLength: Int): String {
        return if (this.length <= maxLength) this else "${this.substring(0, maxLength)}..."
    }
}