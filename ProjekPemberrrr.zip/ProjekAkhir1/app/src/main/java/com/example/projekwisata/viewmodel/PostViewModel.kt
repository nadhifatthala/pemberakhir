package com.example.projekwisata.viewmodel

import androidx.lifecycle.LiveData
import androidx.lifecycle.ViewModel
import com.example.projekwisata.room.PostRepository
import com.example.projekwisata.room.WisataEntity

class PostViewModel(private val postRepository: PostRepository) : ViewModel() {

    fun insertWisata(wisataEntity: WisataEntity) {
        postRepository.insertWisata(wisataEntity)
    }

    fun getAllWisata(): LiveData<List<WisataEntity>> {
        return postRepository.getAllWisata()
    }

    fun deleteWisata(wisataEntity: WisataEntity) {
        postRepository.deleteWisata(wisataEntity)
    }

    fun updateWisata(wisataEntity: WisataEntity) {
        postRepository.updateWisata(wisataEntity)
    }


}

