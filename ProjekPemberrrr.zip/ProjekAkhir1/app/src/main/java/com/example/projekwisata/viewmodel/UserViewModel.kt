package com.example.projekwisata.viewmodel

import androidx.lifecycle.LiveData
import androidx.lifecycle.ViewModel
import com.example.projekwisata.room.UserEntity
import com.example.projekwisata.room.UserRepository

class UserViewModel(private val userRepository: UserRepository) : ViewModel() {

    fun insertUser(user: UserEntity) {
        userRepository.insertUser(user)
    }

    fun getAllUser(): LiveData<List<UserEntity>> {
        return userRepository.getAllUser()
    }

    fun login(email: String, password: String, callback: (UserEntity?) -> Unit) {
        userRepository.login(email, password, callback)
    }

    fun updateUser(user: UserEntity) {
        userRepository.updateUser(user)
    }
}
