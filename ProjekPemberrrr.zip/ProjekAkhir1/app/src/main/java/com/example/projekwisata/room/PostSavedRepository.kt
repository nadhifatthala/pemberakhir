package com.example.projekwisata.room

import androidx.lifecycle.LiveData
import com.example.projekwisata.utils.AppExecutors

class PostSavedRepository private constructor(private val postDao: PostSavedDao, private val appExecutors: AppExecutors) {

    fun getAllWisataByUserId(userId: String): LiveData<List<WisataSavedEntity>> = postDao.getAllWisataByUserId(userId)

    fun insertWisataSaved(wisata: WisataSavedEntity) {
        appExecutors.diskIO().execute { postDao.insertWisataSaved(wisata) }
    }

    fun deleteWisataSaved(wisata: WisataSavedEntity) {
        appExecutors.diskIO().execute { postDao.deleteWisataSaved(wisata) }
    }

    fun updateWisata(wisata: WisataSavedEntity) {
        appExecutors.diskIO().execute { postDao.updateWisata(wisata) }
    }

    companion object {
        @Volatile
        private var instance: PostSavedRepository? = null

        fun getInstance(
            postDao: PostSavedDao,
            appExecutors: AppExecutors
        ): PostSavedRepository = instance ?: synchronized(this) {
                instance ?: PostSavedRepository(postDao, appExecutors)
            }.also { instance = it }
    }
}