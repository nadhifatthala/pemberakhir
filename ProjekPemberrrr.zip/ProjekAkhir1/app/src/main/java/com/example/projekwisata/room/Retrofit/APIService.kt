package com.example.projekwisata.room.Retrofit

import retrofit2.Call
import retrofit2.http.GET


interface APIService {
    // Fungsi ini digunakan untuk mendapatkan semua pemain sepak bola
    @GET("wisata")
    fun getAllPlayers(): Call<List<APIResponse>>


}