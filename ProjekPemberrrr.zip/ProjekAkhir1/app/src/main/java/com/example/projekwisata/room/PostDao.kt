package com.example.projekwisata.room

import androidx.lifecycle.LiveData
import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update

@Dao
interface PostDao {

    @Insert(onConflict = OnConflictStrategy.IGNORE)
    fun insertWisata(wisataEntity: WisataEntity)

    @Query("SELECT * FROM wisataentity ORDER BY id DESC")
    fun getAllWisata() : LiveData<List<WisataEntity>>

    @Delete
    fun deleteWisata(wisataEntity: WisataEntity)

    @Update
    fun updateWisata(wisataEntity: WisataEntity)
}