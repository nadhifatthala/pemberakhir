package com.example.projekwisata

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.ImageView
import android.widget.ProgressBar
import androidx.appcompat.app.AlertDialog
import androidx.lifecycle.ViewModelProvider
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.projekwisata.adapter.AdapterRetrofit
import com.example.projekwisata.room.Retrofit.APIResponse
import com.example.projekwisata.room.Retrofit.ViewModel
import com.example.projekwisata.room.Retrofit.ViewModelFactory
import com.google.android.material.floatingactionbutton.FloatingActionButton

class dummy_apiactivity : AppCompatActivity() {
    // Mendeklarasikan variabel untuk ViewModel
    private lateinit var ViewModel: ViewModel
    // Mendeklarasikan variabel untuk adapter RecyclerView
    private lateinit var adapter: AdapterRetrofit
    // Mendeklarasikan variabel untuk RecyclerView
    private lateinit var recyclerView: RecyclerView

    // Fungsi ini dipanggil saat activity dibuat
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_dummy_apiactivity)

        // Membuat instance dari ViewModel
        val factory = ViewModelFactory.getInstance()
        ViewModel = ViewModelProvider(this, factory)[ViewModel::class.java]

        // Menghubungkan variabel recyclerView dengan komponen di layout
        recyclerView = findViewById(R.id.rv_player_retrofit)
        // Mengatur layoutManager untuk recyclerView
        recyclerView.layoutManager = LinearLayoutManager(this)

        // Memanggil fungsi untuk mendapatkan semua pemain
        ViewModel.getAllPlayer()
        // Mengamati data pemain dari ViewModel
        ViewModel.listPlayer.observe(this) { listPlayer ->
            // Jika listPlayer tidak kosong
            if (listPlayer.isNotEmpty()) {

                // Membuat instance dari adapter dan mengatur adapter untuk recyclerView
                adapter = AdapterRetrofit(listPlayer)
                recyclerView.adapter = adapter

                // Mengatur callback ketika item di klik, di edit, dan di hapus




            }
        }

        // Mengamati data pemain dari ViewModel
        ViewModel.player.observe(this) { player ->
            // Jika player tidak null, memanggil fungsi untuk mendapatkan semua pemain
            if (player != null) {
                ViewModel.getAllPlayer()
            }
        }

        // Mengamati status loading dari ViewModel
        ViewModel.isLoading.observe(this) {
            // Menampilkan atau menyembunyikan loading berdasarkan status loading
            showLoading(it)
        }

        // Mengatur aksi ketika tombol tambah pemain diklik

    }

    // Fungsi untuk menampilkan atau menyembunyikan loading
    private fun showLoading(isLoading: Boolean) {
        val loading = findViewById<ProgressBar>(R.id.progressBar)
        // Jika isLoading true, tampilkan loading. Jika false, sembunyikan loading
        loading.visibility = if (isLoading) View.VISIBLE else View.GONE
    }




    // Fungsi ini dipanggil saat activity di restart
    override fun onRestart() {
        super.onRestart()
        // Memanggil fungsi untuk mendapatkan semua pemain
        ViewModel.getAllPlayer()
    }
}