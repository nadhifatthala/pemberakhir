package com.example.projekwisata.room.Retrofit

import android.util.Log
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class ExRepository {
    // Mendeklarasikan variabel _listPlayer sebagai MutableLiveData yang berisi List dari ExampleAPIResponse
    private val _listPlayer = MutableLiveData<List<APIResponse>>()

    var listPlayer: LiveData<List<APIResponse>> = _listPlayer

    private var _isLoading = MutableLiveData<Boolean>()

    var isLoading: LiveData<Boolean> = _isLoading

    // Mendeklarasikan variabel _player sebagai MutableLiveData yang berisi ExampleAPIResponse
    private val _player = MutableLiveData<APIResponse>()

    // Mendeklarasikan variabel player sebagai LiveData yang berisi ExampleAPIResponse
    var player: LiveData<APIResponse> = _player

    // Fungsi untuk mendapatkan semua pemain
    fun getAllPlayer() {
        // Mengubah nilai _isLoading menjadi true
        _isLoading.value = true
        // Mendapatkan layanan API
        val service = APIConfig.getApiService().getAllPlayers()
        // Mengirim request ke API
        service.enqueue(object : Callback<List<APIResponse>> {
            // Fungsi ini dipanggil ketika mendapatkan response dari API
            override fun onResponse(
                call: Call<List<APIResponse>>,
                response: Response<List<APIResponse>>
            ) {
                // Mengubah nilai _isLoading menjadi false
                _isLoading.value = false

                // Mendapatkan body dari response
                val responseBody = response.body()
                // Jika response sukses dan responseBody tidak null, ubah nilai _listPlayer dengan responseBody
                if (response.isSuccessful && responseBody != null) {
                    _listPlayer.value = response.body()
                } else {
                    // Jika response gagal, log pesan error
                    Log.e("Error on Response", "onFailure: ${response.message()}")
                }
            }

            // Fungsi ini dipanggil ketika request ke API gagal
            override fun onFailure(call: Call<List<APIResponse>>, t: Throwable) {
                // Mengubah nilai _isLoading menjadi false
                _isLoading.value = false
                // Log pesan error
                Log.e("Error on Failure", "onFailure: ${t.message}")
            }
        })
    }

    companion object {
        @Volatile
        private var instance: ExRepository? = null

        // Fungsi untuk mendapatkan instance dari ExampleRepository
        fun getInstance(): ExRepository =
            instance ?: synchronized(this) {
                instance ?: ExRepository()
            }.also { instance = it }
    }
}