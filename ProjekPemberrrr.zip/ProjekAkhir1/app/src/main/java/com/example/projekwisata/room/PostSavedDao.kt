package com.example.projekwisata.room

import androidx.lifecycle.LiveData
import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update

@Dao
interface PostSavedDao {

    @Insert(onConflict = OnConflictStrategy.IGNORE)
    fun insertWisataSaved(wisataEntity: WisataSavedEntity)

    @Query("SELECT * FROM wisatasavedentity WHERE idUser = :userId ORDER BY id DESC")
    fun getAllWisataByUserId(userId: String) : LiveData<List<WisataSavedEntity>>

    @Delete
    fun deleteWisataSaved(wisataEntity: WisataSavedEntity)

    @Update
    fun updateWisata(wisataEntity: WisataSavedEntity)
}