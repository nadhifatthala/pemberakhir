package com.example.projekwisata

import android.content.Intent
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.view.ViewGroup.LayoutParams.WRAP_CONTENT

import android.widget.Button
import androidx.core.view.updateLayoutParams
import androidx.fragment.app.DialogFragment
import androidx.lifecycle.ViewModelProvider
import com.example.projekwisata.room.WisataEntity
import com.example.projekwisata.viewmodel.PostViewModel
import com.example.projekwisata.viewmodel.PostViewModelFactory


class PopUpFragment(private val wisataEntity: WisataEntity, position: Int) : DialogFragment() {

    private lateinit var postViewModel: PostViewModel

    override fun getTheme(): Int {
        return R.style.DialogTheme
    }

    override fun onStart() {
        super.onStart()
        requireDialog().window?.apply {
            setLayout(WRAP_CONTENT, WRAP_CONTENT)
        }

        view?.updateLayoutParams<ViewGroup.MarginLayoutParams> {
            setMargins(16, 16, 16, 16)
        }
    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        return inflater.inflate(R.layout.fragment_pop_up, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        val factory = PostViewModelFactory.getInstance(requireContext())
        postViewModel = ViewModelProvider(this, factory)[PostViewModel::class.java]

        val btnUbah: Button = view.findViewById(R.id.btn_ubah)
        val btnHapus: Button = view.findViewById(R.id.btn_hapus)

        btnUbah.setOnClickListener {
            val intent = Intent(requireContext(), EditWisataActivity::class.java)
            intent.putExtra("dataWisata", wisataEntity)
            startActivity(intent)
            dismiss()
        }

        btnHapus.setOnClickListener {
            postViewModel.deleteWisata(wisataEntity)
            dismiss()
        }
    }

    companion object {
        const val TAG = "PopUpFragment"
    }
}