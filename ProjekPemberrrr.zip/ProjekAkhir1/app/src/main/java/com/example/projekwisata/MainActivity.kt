package com.example.projekwisata

import android.annotation.SuppressLint
import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.TextView
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import androidx.lifecycle.ViewModelProvider
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.projekwisata.adapter.PostAdapterRoom
import com.example.projekwisata.room.WisataEntity
import com.example.projekwisata.user.ProfileActivity
import com.example.projekwisata.viewmodel.PostViewModel
import com.example.projekwisata.viewmodel.PostViewModelFactory

class MainActivity : AppCompatActivity() {

    private var userId: Int = -1
    private var userEmail: String = "testing@gmail.com"
    private var userPass: String = "123"
    private var userLevel: String = "user"

    private lateinit var postViewModel: PostViewModel
    private lateinit var wisataAdapter : PostAdapterRoom
    private lateinit var recyclerView: RecyclerView

    @SuppressLint("MissingInflatedId")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_main)
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }

        //INTENT DATA
        val extras = intent.extras
        userId = extras?.getInt("id", -1) ?: -1
        userEmail = extras?.getString("email", "testing@gmail.com") ?: "testing@gmail.com"
        userPass = extras?.getString("password", "123") ?: "123"
        userLevel = extras?.getString("level", "user") ?: "user"

        val txtWelcome = findViewById<TextView>(R.id.txt_nama)
        txtWelcome.text = "Selamat Datang, $userEmail !"

        val factory = PostViewModelFactory.getInstance(this)
        postViewModel = ViewModelProvider(this, factory)[PostViewModel::class.java]
        recyclerView = findViewById(R.id.rv_wisata)
        recyclerView.layoutManager = GridLayoutManager(this, 1)

        postViewModel.getAllWisata().observe(this) { data ->
            if (data != null) {
                wisataAdapter = PostAdapterRoom(data, postViewModel) //ini
                recyclerView.adapter = wisataAdapter

                wisataAdapter.setOnItemClickCallback(object :
                    PostAdapterRoom.OnItemClickCallback {
                    override fun onMoreClicked(data: WisataEntity, position: Int) {
                        PopUpFragment(data, position).show(supportFragmentManager, PopUpFragment.TAG)
                    }
                })
            }
        }
    }

    fun toAddData(view: View) {
        val intent = Intent(this, AddWisataActivity::class.java)
        startActivity(intent)
    }

    fun forProfileAdmin(view: View) {
        val intent = Intent(this, ProfileActivity::class.java)
        intent.putExtra("id", userId)
        intent.putExtra("email", userEmail)
        intent.putExtra("password", userPass)
        intent.putExtra("level", userLevel)
        startActivity(intent)
    }

    fun toAPI(view: View) {
        val intent = Intent(this, dummy_apiactivity ::class.java)
        startActivity(intent)
    }

}